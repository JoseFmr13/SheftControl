// Validación de login para login.html
document.addEventListener('DOMContentLoaded', function() {
	const form = document.querySelector('form');
	if (!form) return;
	form.addEventListener('submit', function(e) {
		e.preventDefault();
		const inputs = form.querySelectorAll('input[type="text"], input[type="password"]');
		const username = inputs[0].value.trim();
		const password = inputs[1].value;
		// Validar campos vacíos
		if (!username || !password) {
			alert('Por favor, complete ambos campos.');
			return;
		}
		// Validar credenciales
		if (username === 'administrador' && password === 'admin123') {
			window.location.href = 'index.html';
		} else {
			alert('Usuario o contraseña incorrectos.');
		}
	});
});
